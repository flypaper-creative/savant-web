import React from 'react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';

export default function Logo() {
  return (
    <Link 
      to="/" 
      className="relative group block pointer-events-auto"
    >
      <div className="flex items-center gap-6">
        {/* Anchor for the Persistent 3D Logo */}
        <div id="logo-anchor" className="w-16 h-16 relative" />

        <div className="flex flex-col">
          <div className="text-reveal">
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              transition={{ duration: 1, ease: [0.19, 1, 0.22, 1] }}
              className="font-display font-black text-2xl md:text-3xl text-current tracking-tighter leading-none"
            >
              savant<span className="text-neon-pink">.</span>
            </motion.div>
          </div>
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.4 }}
            transition={{ delay: 0.5, duration: 1 }}
            className="font-mono text-[7px] tracking-[0.6em] font-bold uppercase mt-1"
          >
            sovereign_os
          </motion.div>
        </div>
      </div>
    </Link>
  );
}
