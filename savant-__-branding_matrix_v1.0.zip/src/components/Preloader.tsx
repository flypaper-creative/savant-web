import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useLoading } from '../contexts/LoadingContext';

import { useStore } from '../store/useStore';

export const Preloader: React.FC = () => {
  const { phase, progress, enterSite } = useLoading();
  const { template } = useStore();
  const [mouse, setMouse] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMouse({
        x: (e.clientX / window.innerWidth) * 2 - 1,
        y: -(e.clientY / window.innerHeight) * 2 + 1
      });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const showUI = phase === 'booting' || phase === 'ready';
  const showBackground = phase !== 'complete';

  // Custom easing for Awwwards-style motion
  const customEase = [0.19, 1, 0.22, 1];

  const getTemplateBg = () => {
    switch (template) {
      case 1: return "bg-[#0a0c10]"; // Gunmetal Dark
      case 2: return "bg-[#050505]"; // Deep Obsidian
      case 3: return "bg-[#0d1117]"; // Midnight Blue/Gray
      default: return "bg-[#0a0c10]";
    }
  };

  return (
    <AnimatePresence>
      {showBackground && (
        <motion.div
          className="fixed inset-0 z-[14000] overflow-hidden text-white"
          exit={{ 
            opacity: 0, 
            transition: { duration: 4, ease: [0.19, 1, 0.22, 1] } 
          }}
        >
          {/* Flash Effect on Exit */}
          <motion.div 
            className="absolute inset-0 bg-white z-[100] pointer-events-none"
            initial={{ opacity: 0 }}
            animate={{ opacity: phase === 'transition' ? [0, 1, 0] : 0 }}
            transition={{ duration: 2.5, ease: "easeInOut" }}
          />
          
          {/* Scanlines Overlay */}
          <div className="absolute inset-0 pointer-events-none z-[1] opacity-10 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_2px,3px_100%]" />
          
          {/* Semi-transparent Overlay - Allows 3D scene to be visible during loading */}
          <motion.div 
            className="absolute inset-0 pointer-events-none"
            animate={{ 
              opacity: phase === 'transition' ? 0 : 1,
              scale: phase === 'transition' ? 1.5 : 1
            }}
            transition={{ duration: 4, ease: [0.19, 1, 0.22, 1] }}
            style={{
              background: `radial-gradient(circle at center, transparent 0%, rgba(10, 12, 16, 0.4) 40%, rgba(10, 12, 16, 0.95) 100%)`,
              backdropFilter: phase === 'transition' ? 'blur(0px)' : 'blur(4px)'
            }}
          />

          {/* 2D UI Overlay */}
          <AnimatePresence>
            {showUI && (
              <motion.div 
                className="absolute inset-0 z-10 flex flex-col justify-center items-center p-6 md:p-12 overflow-hidden text-white pointer-events-none"
                exit={{ 
                  opacity: 0, 
                  scale: 1.1,
                  filter: 'blur(20px)', 
                  transition: { duration: 2, ease: [0.19, 1, 0.22, 1] } 
                }}
              >
                {/* Savant Precision Loader (Mandala-like UI) */}
                <div className="relative w-full h-full flex items-center justify-center">
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 2, ease: [0.19, 1, 0.22, 1] }}
                    className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[min(78vw,820px)] aspect-square pointer-events-none opacity-20"
                  >
                    <div className="relative w-full h-full">
                      {/* Base Ring */}
                      <div className="absolute inset-0 border border-white/20 rounded-full" style={{ clipPath: 'polygon(50% 0%, 74% 3%, 92% 13%, 100% 50%, 92% 87%, 74% 97%, 50% 100%, 26% 97%, 8% 87%, 0% 50%, 8% 13%, 26% 3%)' }} />
                      {/* Inner Ring */}
                      <div className="absolute inset-[42px] border border-[#00E5FF]/20 rounded-full" style={{ clipPath: 'polygon(50% 0%, 73% 4%, 90% 14%, 100% 50%, 90% 86%, 73% 96%, 50% 100%, 27% 96%, 10% 86%, 0% 50%, 10% 14%, 27% 4%)' }} />
                      {/* Orbiting Arc */}
                      <motion.div 
                        animate={{ rotate: 360 }}
                        transition={{ duration: 4.2, repeat: Infinity, ease: "linear" }}
                        className="absolute inset-[12px] rounded-full"
                      >
                        <div className="absolute inset-0 rounded-full" style={{ 
                          background: 'conic-gradient(from 0deg, rgba(255,42,95,0) 0deg, rgba(255,42,95,0) 212deg, rgba(255,184,0,.08) 236deg, rgba(0,229,255,.36) 264deg, rgba(255,255,255,1) 286deg, rgba(255,42,95,1) 304deg, rgba(255,42,95,.10) 320deg, rgba(255,42,95,0) 360deg)',
                          WebkitMask: 'radial-gradient(circle, transparent 63.4%, #000 64%, #000 66.6%, transparent 67.2%)',
                          mask: 'radial-gradient(circle, transparent 63.4%, #000 64%, #000 66.6%, transparent 67.2%)'
                        }} />
                      </motion.div>
                    </div>
                  </motion.div>

                  <div className="absolute bottom-[15%] flex flex-col items-center justify-center w-full">
                    <AnimatePresence mode="wait">
                      {phase === 'booting' ? (
                        <motion.div
                          key="loading"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="flex flex-col items-center"
                        >
                          <div className="font-mono text-[10px] font-bold text-[#E6C03B] tracking-[1em] uppercase text-center leading-loose mb-8">
                            <motion.span
                              animate={{ opacity: [1, 0.5, 1] }}
                              transition={{ duration: 0.1, repeat: Infinity, repeatType: "reverse" }}
                            >
                              [ SYSTEM_INITIALIZING ]
                            </motion.span>
                            <br/>
                            wallace_arch // seq_v36.1 // {progress.toString().padStart(3, '0')}%
                          </div>
                          <div className="w-[400px] h-[4px] bg-white/5 overflow-hidden relative border border-white/10 backdrop-blur-xl">
                            <motion.div
                              className="absolute inset-y-0 left-0 bg-gradient-to-r from-[#00E5FF] via-[#FF4068] to-[#E6C03B] shadow-[0_0_20px_rgba(0,229,255,0.5)]"
                              style={{ width: `${progress}%` }}
                              transition={{ duration: 0.1 }}
                            />
                          </div>
                        </motion.div>
                      ) : (
                        <motion.button
                          key="enter"
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 1.2, filter: 'blur(20px)' }}
                          transition={{ duration: 2, ease: [0.19, 1, 0.22, 1] }}
                          onClick={(e) => {
                            e.stopPropagation();
                            enterSite();
                          }}
                          className="pointer-events-auto font-sans text-[12px] tracking-[1.5em] font-black text-white px-16 py-6 border border-white/20 bg-black/40 backdrop-blur-xl uppercase whitespace-nowrap outline-none relative overflow-hidden group transition-all duration-500 hover:border-white/60 hover:tracking-[1.8em] hover:shadow-[0_0_100px_rgba(255,255,255,0.1)] active:scale-95"
                        >
                          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                          <span className="relative z-10 ml-[1.5em]">[ initialize ]</span>
                        </motion.button>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
