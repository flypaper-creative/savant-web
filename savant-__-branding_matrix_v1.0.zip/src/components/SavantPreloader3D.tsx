import React, { useMemo, useRef, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { 
  Environment, 
  MeshTransmissionMaterial, 
  MeshReflectorMaterial,
  PerspectiveCamera,
  Float
} from '@react-three/drei';
import * as THREE from 'three';
import gsap from 'gsap';
import { EffectComposer, Bloom, ChromaticAberration, Noise, Vignette } from '@react-three/postprocessing';
import { useLoading } from '../contexts/LoadingContext';

const Logo = ({ phase, mouse }: { phase: string, mouse: React.MutableRefObject<{ x: number, y: number }> }) => {
  const groupRef = useRef<THREE.Group>(null);
  const coreRef = useRef<THREE.Mesh>(null);
  const transitionStarted = useRef(false);
  
  const curve = useMemo(() => {
    const points = [];
    const segments = 200;
    for (let i = 0; i <= segments; i++) {
      const t = (i / segments) * Math.PI * 2;
      const r = 3.2 * (1 + 0.4 * Math.cos(3 * t));
      const x = r * Math.sin(t);
      const y = r * Math.cos(t);
      const z = 0.6 * Math.sin(3 * t);
      points.push(new THREE.Vector3(x, y, z));
    }
    return new THREE.CatmullRomCurve3(points, true);
  }, []);

  useEffect(() => {
    if (phase === 'transition' && !transitionStarted.current && groupRef.current) {
      transitionStarted.current = true;
      gsap.to(groupRef.current.position, {
        z: 100,
        duration: 3.5,
        ease: "power3.inOut"
      });
      gsap.to(groupRef.current.rotation, {
        y: groupRef.current.rotation.y + Math.PI * 4,
        duration: 4,
        ease: "power2.inOut"
      });
    }
  }, [phase]);

  useFrame((state) => {
    if (!groupRef.current) return;
    const t = state.clock.getElapsedTime();

    if (phase !== 'transition') {
      groupRef.current.rotation.y += 0.01;
      groupRef.current.rotation.x = THREE.MathUtils.lerp(groupRef.current.rotation.x, Math.sin(t * 0.8) * 0.1 + mouse.current.y * 0.4, 0.05);
      groupRef.current.rotation.z = THREE.MathUtils.lerp(groupRef.current.rotation.z, mouse.current.x * 0.2, 0.05);
      groupRef.current.position.x = THREE.MathUtils.lerp(groupRef.current.position.x, mouse.current.x * 4, 0.03);
      groupRef.current.position.y = THREE.MathUtils.lerp(groupRef.current.position.y, mouse.current.y * 4, 0.03);
      
      const s = 1.2 + Math.sin(t * 2) * 0.05;
      groupRef.current.scale.set(s, s, s);
    }

    if (coreRef.current) {
      coreRef.current.rotation.y = -t * 0.4;
    }
  });

  return (
    <Float speed={2} rotationIntensity={0.5} floatIntensity={0.5}>
      <group ref={groupRef}>
        {/* Main Glassy Structure */}
        <mesh castShadow receiveShadow>
          <tubeGeometry args={[curve, 200, 0.4, 32, true]} />
          <MeshTransmissionMaterial 
            backside
            samples={16}
            thickness={1.5}
            chromaticAberration={0.1}
            anisotropy={0.5}
            distortion={0.2}
            distortionScale={0.2}
            temporalDistortion={0.1}
            ior={1.4}
            color="#ffffff"
            resolution={512}
            transmission={1}
            roughness={0.02}
            metalness={0.9}
            clearcoat={1}
            clearcoatRoughness={0.1}
            envMapIntensity={5.0}
            emissive="#E6C03B"
            emissiveIntensity={0.1}
          />
        </mesh>

        {/* Glowing Core */}
        <mesh ref={coreRef}>
          <tubeGeometry args={[curve, 200, 0.1, 12, true]} />
          <meshBasicMaterial color="#FF4068" />
        </mesh>

        <pointLight position={[0, 0, 10]} color="#E6C03B" intensity={150} distance={50} decay={2} />
        <pointLight position={[0, 0, -10]} color="#FF4068" intensity={100} distance={50} decay={2} />
        <pointLight position={[0, 5, 5]} color="#00E5FF" intensity={80} distance={30} decay={2} />
        <spotLight position={[0, 10, 20]} angle={0.15} penumbra={1} intensity={200} color="#ffffff" castShadow />
      </group>
    </Float>
  );
};

const Atmosphere = ({ phase, mouse }: { phase: string, mouse: React.MutableRefObject<{ x: number, y: number }> }) => {
  const ringRef = useRef<THREE.Group>(null);
  const transitionStarted = useRef(false);

  useEffect(() => {
    if (phase === 'transition' && !transitionStarted.current && ringRef.current) {
      transitionStarted.current = true;
      // Preloader ring zooms past camera faster than logo
      gsap.to(ringRef.current.position, {
        z: 150,
        duration: 2.5,
        ease: "power4.inOut"
      });
    }
  }, [phase]);

  useFrame((state) => {
    if (ringRef.current) {
      ringRef.current.rotation.z += 0.005;
      
      if (phase !== 'transition') {
        // Parallax for the ring - more significant
        ringRef.current.position.x = THREE.MathUtils.lerp(ringRef.current.position.x, mouse.current.x * 6, 0.03);
        ringRef.current.position.y = THREE.MathUtils.lerp(ringRef.current.position.y, mouse.current.y * 6, 0.03);
      }
    }
  });

  return (
    <group>
      {/* Circular Preloader Ring */}
      <group ref={ringRef}>
        {Array.from({ length: 24 }).map((_, i) => (
          <mesh key={i} position={[Math.cos((i / 24) * Math.PI * 2) * 12, Math.sin((i / 24) * Math.PI * 2) * 12, 0]}>
            <boxGeometry args={[0.2, 1.5, 0.2]} />
            <meshStandardMaterial 
              color={i % 2 === 0 ? "#E6C03B" : "#FF4068"} 
              emissive={i % 2 === 0 ? "#E6C03B" : "#FF4068"}
              emissiveIntensity={10}
            />
          </mesh>
        ))}
      </group>

      {/* Floor */}
      <mesh rotation={[-Math.PI * 0.5, 0, 0]} position={[0, -15, 0]}>
        <planeGeometry args={[200, 200]} />
        <MeshReflectorMaterial
          blur={[400, 100]}
          resolution={512}
          mixBlur={1}
          mixStrength={10}
          roughness={1}
          depthScale={1.2}
          minDepthThreshold={0.4}
          maxDepthThreshold={1.4}
          color="#0a0c10"
          metalness={0.5}
          mirror={0.5}
        />
      </mesh>
      <gridHelper args={[200, 50, 0x00E5FF, 0x05070B]} position={[0, -14.9, 0]} />
    </group>
  );
};

const CameraHandler = ({ phase }: { phase: string }) => {
  const { camera } = useThree();
  const transitionStarted = useRef(false);

  useEffect(() => {
    if (phase === 'transition' && !transitionStarted.current) {
      transitionStarted.current = true;
      // Smooth camera move forward
      gsap.to(camera.position, {
        z: -100,
        duration: 4,
        ease: "power4.inOut",
        onUpdate: () => {
          camera.lookAt(0, 0, 0);
        }
      });
    }
  }, [phase, camera]);

  useFrame(() => {
    if (phase !== 'transition') {
      camera.lookAt(0, 0, 0);
    }
  });

  return null;
};

export const SavantPreloader3D = () => {
  const { phase, isLoading } = useLoading();
  const mouse = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mouse.current = {
        x: (e.clientX / window.innerWidth) * 2 - 1,
        y: -(e.clientY / window.innerHeight) * 2 + 1
      };
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  if (!isLoading && phase === 'complete') return null;

  return (
    <div className="fixed inset-0 z-[13000] pointer-events-none bg-[#0a0c10]">
      <Canvas 
        shadows 
        dpr={[1, 1.5]} 
        gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
      >
        <PerspectiveCamera makeDefault position={[0, 0, 25]} fov={35} />
        <fogExp2 attach="fog" color={0x0a0c10} density={0.015} />
        <ambientLight intensity={0.5} />
        <Environment preset="night" />
        
        <CameraHandler phase={phase} />
        <Logo phase={phase} mouse={mouse} />
        <Atmosphere phase={phase} mouse={mouse} />

        <EffectComposer multisampling={0}>
          <Bloom intensity={2.5} luminanceThreshold={0.1} mipmapBlur />
          <ChromaticAberration offset={new THREE.Vector2(0.002, 0.002)} />
          <Noise opacity={0.03} />
          <Vignette offset={0.5} darkness={0.8} />
        </EffectComposer>
      </Canvas>
    </div>
  );
};
