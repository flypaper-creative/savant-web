import React, { useRef } from 'react';
import { motion, useInView } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { DistortedImage } from '../components/DistortedImage';

const SplitText = ({ children, delay = 0, className = "" }: { children: string, delay?: number, className?: string }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-10%" });
  
  const words = children.split(" ");
  
  const container: any = {
    hidden: { opacity: 0 },
    visible: (i = 1) => ({
      opacity: 1,
      transition: { staggerChildren: 0.05, delayChildren: delay * i },
    }),
  };

  const child: any = {
    visible: {
      opacity: 1,
      y: 0,
      rotate: 0,
      transition: { type: "spring", damping: 20, stiffness: 100 },
    },
    hidden: {
      opacity: 0,
      y: 50,
      rotate: 5,
      transition: { type: "spring", damping: 20, stiffness: 100 },
    },
  };

  return (
    <motion.div
      ref={ref}
      className={`flex flex-wrap ${className}`}
      variants={container}
      initial="hidden"
      animate={isInView ? "visible" : "hidden"}
    >
      {words.map((word, index) => (
        <motion.span
          variants={child}
          style={{ marginRight: "0.25em" }}
          key={index}
          className="inline-block"
        >
          {word}
        </motion.span>
      ))}
    </motion.div>
  );
};

const RevealText = ({ children, delay = 0 }: { children: React.ReactNode, delay?: number }) => (
  <div className="overflow-hidden">
    <motion.div
      initial={{ y: "120%", rotate: 2 }}
      whileInView={{ y: 0, rotate: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 1.2, delay, ease: [0.19, 1, 0.22, 1] }}
    >
      {children}
    </motion.div>
  </div>
);

export default function Contact() {
  return (
    <div className="w-full min-h-screen flex flex-col justify-center px-6 md:px-12 relative overflow-hidden text-current">
      <DistortedImage src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2672&auto=format&fit=crop" className="absolute inset-0 z-[-1] opacity-10" intensity={0.2} />
      <div className="absolute inset-0 neural-lattice-overlay opacity-20 pointer-events-none" />
      
      <div className="max-w-7xl mx-auto w-full relative z-10 grid grid-cols-1 md:grid-cols-12 gap-12">
        <div className="md:col-span-7">
          <div className="text-label mb-12 flex items-center gap-4">
            <div className="w-2 h-2 bg-gold opacity-50 rounded-full animate-pulse" />
            secure channel // v80.0
          </div>
          
          <h1 className="text-[14vw] md:text-[10vw] font-serif leading-[0.8] tracking-tighter mb-16 text-white">
            <RevealText>initiate</RevealText>
            <RevealText delay={0.1}><span className="opacity-30 italic">uplink.</span></RevealText>
          </h1>
          
          <div className="max-w-2xl">
            <SplitText delay={0.2} className="text-xl md:text-2xl opacity-70 font-light leading-relaxed mb-20 text-white">
              ready to architect your operational reality? establish a secure connection with our core nodes. we operate strictly on a carte blanche basis for elite clientele.
            </SplitText>
          </div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 1 }}
            className="flex flex-col gap-12"
          >
            <a href="mailto:transmission@savant.ai" className="group flex items-center gap-8 text-4xl md:text-6xl font-serif font-black hover:italic transition-all duration-700 w-fit text-white">
              transmission@savant.ai
              <ArrowRight className="w-10 h-10 opacity-0 group-hover:opacity-100 group-hover:translate-x-6 transition-all duration-700 text-gold" />
            </a>
            
            <div className="flex gap-16 font-mono text-[10px] tracking-[0.5em] opacity-30 pt-16 border-t border-white/10 uppercase">
              <a href="#" className="hover:text-gold hover:opacity-100 transition-all">twitter</a>
              <a href="#" className="hover:text-gold hover:opacity-100 transition-all">instagram</a>
              <a href="#" className="hover:text-gold hover:opacity-100 transition-all">linkedin</a>
            </div>
          </motion.div>
        </div>

        <div className="md:col-span-4 md:col-start-9 hidden md:flex flex-col justify-end pb-12">
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.8, duration: 1, ease: [0.19, 1, 0.22, 1] }}
            className="p-12 rounded-[3rem] border border-white/5 bg-white/[0.02] backdrop-blur-3xl relative overflow-hidden"
          >
            {/* Scanlines */}
            <div className="absolute inset-0 pointer-events-none z-0 opacity-[0.03] bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_2px,3px_100%]" />

            <div className="font-mono text-[10px] opacity-40 tracking-[0.5em] mb-10 uppercase relative z-10">system_status</div>
            <div className="flex flex-col gap-6 relative z-10">
              <div className="flex justify-between items-center border-b border-white/5 pb-6">
                <span className="font-mono text-[10px] opacity-30 uppercase">availability</span>
                <span className="font-mono text-[10px] text-emerald-400 uppercase tracking-widest">accepting_transmissions</span>
              </div>
              <div className="flex justify-between items-center border-b border-white/5 pb-6">
                <span className="font-mono text-[10px] opacity-30 uppercase">encryption</span>
                <span className="font-mono text-[10px] text-white uppercase tracking-widest">aes-256_active</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="font-mono text-[10px] opacity-30 uppercase">response_time</span>
                <span className="font-mono text-[10px] text-white uppercase tracking-widest">&lt; 24_hours</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
